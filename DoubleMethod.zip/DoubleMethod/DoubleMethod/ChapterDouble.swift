

//nan in Double
//nan not a number
//nan value can be stored but we cannot do operation with it
//and nan cannot be representable in our UI
//we have a method to check nan value(we can check it is an nan value or finite value)

import Foundation

class ChapterDouble{
    
  
    
   
}
