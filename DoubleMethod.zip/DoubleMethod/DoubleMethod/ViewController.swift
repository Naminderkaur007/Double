

//why we should used
//when we should used ,for an example
//should know


import UIKit

class ViewController: UIViewController {

  

      //**************************************
        
        func useOfInitdouble(){
    //        Creates a new value, rounded to the closest possible representation.
            let x = Double(55.6)
            print("x double = \(x)")
        }
           func useOfInit(){
        //        Creates a value initialized to zero.
                let x = Double.init()
                print("x = \(x)")
            }
            
            func useOfInitFloatLiteral(){
        //        Creates a new value from the given floating-point literal.
                let x = Double.init(floatLiteral: 21.25)
                print("x = \(x)")
            }
            
       
            func useOfIsZero(){
                // check zero value.
                let x = Double.zero
                if x.isZero {
                    print("YES")
                }
            }
        
        
        
        //***************************************************
        
   
        
        func useOfNAN(){
               print("Not a number")
            
               let x = Double.nan
               print(x.isNaN)//True
            
               
              let f = Double("nan")
              print("f double = \(f) also \(f?.isNaN)")
           }
    
    
    
    
    
         func useOfIsEqual(){
// Returns a Boolean value indicating whether this instance is equal to the given value.
//we can't check nan to isEqual

                let x = 15.0
            
                print(x.isEqual(to: 15.0))
            
                print(x.isEqual(to: .nan)) //false
              
                print(Double.nan.isEqual(to: .nan)) // NaN is not equal to any value, including itself.//false
        }
    
    
        
    
        func useOfInitString(){
        //        Creates a new instance from the given string.

            
            //***********this is function overloading ,it understand the string and convert it into the double and return the optional value
                let a = Double("-1.0")
                print("a double = \(a)")
             
                let b = Double("28.375")
                print("b double = \(b)")
   
            //***********************
            
            
        // A value of infinity contains one of the strings "inf" or "infinity", case insensitive.
        //it understand the inf and -Infinity string
        
               let c = Double("inf")
                print("c double = \(c))")
              
                let d = Double("-Infinity")
                print("d double = \(d)")
                
            //*************************************
            
                let e = Double("Hello World");
                print("e double = \(e)")
     
            }

          func useOfMinimum(){
        //        Returns the lesser of the two given values.
            //here nan is treat like a biggest positive value in minimum method
                print(Double.minimum(10.0, -25.0))
                print(Double.minimum(10.0, .nan))
                print(Double.minimum(.nan, -25.0))
                print(Double.minimum(.nan, .nan))
            }
              func useOfMaximum(){
          //        Returns the greater of the two given values.
                  //it support finite number not a nan
                //here nan is treat like a biggest  negative value in maximum method
                  print(Double.maximum(10.0, -25.0))
                  print(Double.maximum(10.0, .nan))
                  print(Double.maximum(.nan, -25.0))
                  print(Double.maximum(.nan, .nan))
              }
            
          
        
            func useOfIsFinite(){
        
                //All values other than NaN and infinity are considered finite, whether normal or subnormal.
                //nan is infinity number
                
                let x = Double.nan
                let y = Double("inf")
                
                //both x and y are infinity
                
                if x.isFinite {
                    print("YES")
                }else{
                    print("NO")
                }
            }

             func useOfIsNormal(){
                
            //A Boolean value indicating whether this instance is normal. zero is not normal value
            //it will not take nan and zero value
                
                //it safes u from zero and nan also
                
                    let x = Double.zero
                    if x.isNormal {
                        print("YES")
                    }else{
                        print("NO")
                    }
                }
                
    
        
        
        //************
    
    
        
        func useOfInitSignOfMagnititude(){
    //        Creates a new floating-point value using the sign of one value and the magnitude of another.


            let a = -21.5
            let b = 305.15
            let c = Double(signOf: a, magnitudeOf: b)
            print("c = \(c)")
        }

        func useOfInitExactly(){
    //        Creates a new instance initialized to the given value, if it can be represented without rounding.

            //it return optional value

            let x = 21.25
            let y = Double(exactly: x)
            print("y = \(y)")
      
            let z = Double(exactly: Double.nan)
            print("z = \(z)")
       
            let a = Double(Double.nan)
            print("a = \(a)")
        }

        func useOfRandomIn(){
    //        Returns a random value within the specified range.
            for _ in 1...3{
                print(Double.random(in: 10.0..<20.0))
            }
        }
        
        func useOfAddingProduct(){
    //        Returns the result of adding the product of the two given values to this value, computed without intermediate rounding.
            let a = 40.0
            let b = 30.0
            let c =  a.addingProduct(a, b)
            print("Adding product = \(c)")
        }

        func useOfAddProduct(){
    //        Adds the product of the two given values to this value in place, computed without intermediate rounding.
            var a = 40.0
            let b = 30.0
            a.addProduct(5, b)
            print("add product = \(a)")

        }
        
        func useOfSquareRoot(){
    //        Returns the square root of the value, rounded to a representable value.
            let a = 2.0
            let b = a.squareRoot()
            print("Square root = \(b)")
        }
        
        func useOfFormSquareRoot(){
    //        Replaces this value with its square root, rounded to a representable value.
            var a = 3.0
            a.formSquareRoot()
            print("Square root = \(a)")
        }
        
        func useOfReminder(){
    //        Returns the remainder of this value divided by the given value.
            let x = 8.625
            let r = x.remainder(dividingBy: 0.2)
            print(r)

        }
        
        func useOfFormReminder(){
    //        Replaces this value with the remainder of itself divided by the given value.
            var x = 8.625
            x.formRemainder(dividingBy: 0.2)
            print(x)
        }
        
      

        func useOfRounded(){
    //        Returns this value rounded to an integral value using “schoolbook rounding.”


            print((5.2).rounded())//5
            print((5.5).rounded())//6
            print((-5.2).rounded())//-5
            print((-5.5).rounded())//-6
        }

        //floor
        func callFloorFunction(){
    //        Rounds any number with a decimal value down to the next smaller whole number

            print(floor(3.000)) //3
            print(floor(3.001))//3
            print(floor(3.999))//3   *
            print(floor(-3.000))//-3
            print(floor(-3.001))//-4   *
            print(floor(-3.999))//-4

        }
        //ceil
        func callCeilFunction(){
    //        Rounds any number with a decimal value up to the next larger whole number.
            print(ceil(3.000))//3
            print(ceil(3.001))//4    *
            print(ceil(3.999))//4
            print(ceil(-3.000))//-3
            print(ceil(-3.001))//-3
            print(ceil(-3.999))//-3    *

        }
        
        func useOfRoundedWithOption(){
    //        Rounds the value to an integral value using the specified rounding rule.
            print((6.5).rounded(.toNearestOrAwayFromZero)) // Equivalent to the C 'round' function: //7
            print((6.5).rounded(.towardZero)) // Equivalent to the C 'trunc' function://6
            print((6.2).rounded(.up)) // Equivalent to the C 'ceil' function://7
            print((6.5).rounded(.down)) // Equivalent to the C 'floor' function://6
        }
        
       
        
        func useOfIsTotallyOrdered(){
    //        Returns a Boolean value indicating whether this instance should precede or tie positions with the given value in an ascending sort.
            var numbers = [2.5, 21.5, 3.0, .nan, -9.5]
            numbers.sort { (a, b) -> Bool in
                return !b.isTotallyOrdered(belowOrEqualTo: a)
            }
            print(numbers)
        }

      
        func useOfMagnitude(){
    //        The magnitude of this value.
            let x = -5.25
            print("Normal x = \(x)")
            print("Magnitude x = \(x.magnitude)")
        }
    
    
    override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           
      useOfDistanceTo()
    
       }
      
        
        func useOfSign(){
    //        The sign of the floating-point value.
            let x = -5.25
            print("Normal x = \(x)")
            print("Sign x = \(x.sign)")
            let y = 5.25
            print("Normal y = \(y)")
            print("Sign y = \(y.sign)")
        }
        
        func useOfPI(){
    //        The mathematical constant pi.
            print("Pi = \(Double.pi)")
        }
        
       
        
        func useOfGreatestFiniteMagnitude(){
            // check greatest finitemagnitude
            let x = Double.greatestFiniteMagnitude
            print("x = \(x)")
        }
        
       
        
        func useOfLeastNormalMagnitude(){
    //        The least normal number.
            let x = Double.leastNormalMagnitude
            print("x = \(x)")
        }

        func useOfAdvanceBy(){
    //        Returns a new value advanced by the given distance.


            let x = 21.5
            let y = x.advanced(by: -6.5)
            print("y = \(y)")
        }

        func useOfDistanceTo(){
    //        Returns the distance from this value to the specified value.
            let x = 21.5
            let y = x.distance(to: 15.0)
            print("y = \(y)")
        }
        

}

